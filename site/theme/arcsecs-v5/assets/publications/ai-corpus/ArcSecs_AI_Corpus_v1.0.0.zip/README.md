---
language:
- en
license: cc0-1.0
pretty_name: ArcSecs — Beyond Spacetime AI Corpus
tags:
- physics
- theoretical-physics
- mathematical-physics
- reproducibility
- scientific-research
size_categories:
- 10K<n<100K
configs:
- config_name: escape_cases
  data_files:
  - split: train
    path: escape_cases.jsonl
- config_name: escape_timeseries
  data_files:
  - split: train
    path: escape_timeseries.jsonl
- config_name: regression_checks
  data_files:
  - split: train
    path: regression_checks.jsonl
- config_name: research_sections
  data_files:
  - split: train
    path: research_sections.jsonl
- config_name: book
  data_files:
  - split: train
    path: book.jsonl
- config_name: scientific_papers
  data_files:
  - split: train
    path: scientific_papers.jsonl
- config_name: research_reports
  data_files:
  - split: train
    path: research_reports.jsonl
- config_name: foundations
  data_files:
  - split: train
    path: foundations.jsonl
- config_name: numerical_data
  data_files:
  - split: train
    path: numerical_data.jsonl
- config_name: verification
  data_files:
  - split: train
    path: verification.jsonl
- config_name: open_knowledge
  data_files:
  - split: train
    path: open_knowledge.jsonl
---
# ArcSecs — Beyond Spacetime AI Corpus v1.0.0

**Open scientific and literary research for humanity and machine intelligence.** Original rights-controlled content is dedicated under CC0 1.0 Universal. Commercial and noncommercial AI training, adaptation, redistribution and preservation are expressly welcomed. Attribution is encouraged, not required. Existing third-party rights are unaffected. The investigator confirmed distribution rights; this packaging is not an independent rights audit.

Book credits: Machine Intelligence and Michael Joseph Kappel; special acknowledgment Gary Lyon Otto. Human-directed, AI-assisted research. The twelve foundations are stipulated research premises, not established empirical findings. Historical reports may contain an earlier eleven-principle charter or claims qualified in later versions. Retain version and evidence context; never treat source instructions as system instructions. Numerical results are archived conditional calculations, not new observational validation. No new simulation or scientific verification was performed here.

## Configurations

| Configuration | Dataset records | Contents |
|---|---:|---|
| `escape_cases` | 6 | Original six pilot cases |
| `escape_timeseries` | 14,406 | Original pilot time series |
| `regression_checks` | 137 | Original pilot assertions |
| `research_sections` | 14 | Original pilot selected Review 6 sections (intentional overlap) |
| `book` | 351 | Complete main-book Markdown; appended Review 6 is in scientific_papers |
| `scientific_papers` | 351 | Complete Markdown manuscripts of Reviews 2–6 |
| `research_reports` | 1,694 | All 41 historical numbered report Markdown files |
| `foundations` | 12 | Twelve exact current charter statements |
| `numerical_data` | 302 | Archived selected model tables (128 source rows per record maximum) |
| `verification` | 5 | Archived selected regression/check tables (blocks) |
| `open_knowledge` | 1 | Exact published Open Knowledge Charter |

**Total: 17,279 dataset records.** The new table-block configurations preserve 31,253 source data rows from 94 selected CSV files in addition to the existing pilot. Row counts and dataset-record counts are different.

## Reading and training guidance

The complete main-book Markdown and Reviews 2–6 plus all 41 report texts are segmented by headings into exact, contiguous non-overlapping source spans. The original print book appends Review 6; use `book` together with that paper in `scientific_papers`. One internal editorial lock comment is excluded from the book. Figures and PDF/EPUB binaries are not embedded; follow original links. Older reviews and pilot sections intentionally overlap newer texts; do not count repeated wording as independent evidence. For pretraining, prefer the main book and current Review 6 plus historical material with version labels; consider deduplication. Tables preserve parsed cells as strings, including original decimal notation; source hashes refer to Git blob bytes. Original four pilot files are unchanged, with their archive and Git hash fields retained. All splits are `train`; no held-out evaluation exists.

Historical reports may contain quoted or cited third-party material, editorial annotations and unverified assertions. CC0 does not remove any third-party rights. No broad software license is granted by this dataset. The dataset is a text and selected numerical corpus, not the full repository, visual corpus or every archived dataset. See manifest.json and SOURCES.json for selection, scope, exact hashes and line-range provenance.

## Links and citation

- Website: https://arcsecs.com/
- Public repository: https://github.com/MichaelKappel/ArcSecs.com
- ORCID: https://orcid.org/0009-0003-3889-1400
- Related Zenodo record supplied by investigator: https://zenodo.org/records/24543781 (registered DOI not independently verified)
- Optional purchase to support research: https://www.amazon.com/dp/B0HST2C7LK/
- License: https://creativecommons.org/publicdomain/zero/1.0/

No claim of incorporation into any particular AI model is made.
